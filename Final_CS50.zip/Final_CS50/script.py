import random 
import string
import tkinter
from pyperclip import copy

# Create a function to generate a random password
def Password():
    password = ""
    for i in range(dv_length.get()):
        password = password + random.choice(string.ascii_lowercase + string.ascii_uppercase + string.digits 
        + "!#$%&'*+=-/<>?@_()")
    dv_password.set(password)

# Create a second function to copy the password in the clipboard to paste it anywhere
def Copy():
    if dv_password.get() == '':
        error = tkinter.Label(window, text="Generate something first!", font=("Helvetica", 10, "italic"), width=25)
        error.place(x=120, y=120)

    else:
        copy(dv_password.get())
        ok = tkinter.Label(window, text="Copied!", font=("Helvetica", 10, "italic"), width=25)
        ok.place(x=120, y=120)

# With tkinter library, we use several functions to create a window, name it, then set its size
window = tkinter.Tk()
window.title("Password-Generator")
window.geometry("400x200")
window.resizable(False, False)

# Create the labels inside the window
label_length = tkinter.Label(window, text="Password length", font=("Helvetica", 14, "bold"))
label_length.pack()

# Initialize a dynamic variable for length selection
dv_length = tkinter.IntVar()

# Create a increase/decrease widget
length = tkinter.Spinbox(window, from_= 3, to_= 20, textvariable=dv_length, width=2)
length.pack(pady=10)

label_result = tkinter.Label(window, text="Your password: ", font=("Helvetica", 14, "bold"))
label_result.pack()

# Link a dynamic variable to a text field
dv_password = tkinter.StringVar()
textData = tkinter.Entry(window, textvariable=dv_password, show="•", width=14)
textData.pack()

# Create the buttons to interact with
button_generate = tkinter.Button(window, text="Generate", command=Password)
button_generate.pack(padx=75,pady=5,side=tkinter.LEFT)

button_copy = tkinter.Button(window, text="Copy", command=Copy)
button_copy.pack(side=tkinter.LEFT)

# Create an option to hide/reveal the generated password
def Show_password():
    if textData.cget("show") == "•":
        textData.config(show="")
    else:
        textData.config(show="•")

reveal_button = tkinter.Checkbutton(window, text="Reveal", command=Show_password)
reveal_button.place(x=270, y=94)

window.mainloop()