# Password-Generator
#### Video Demo:  https://www.youtube.com/watch?v=UpYgR5fuuJg
#### Description:

My project is a strong password generator, it's simple as that! The main purpose of this program is to create strong passwords with different character types in order to maximize the account's security. 

I didn't want to host it on a server (because I prefer standalone software) and with HTTP protocol (not HTTPS) someone could "sniff" the generated password.
So I used a library called "tkinter" to create the main window and all the functionalities (labels, counter, buttons, checkbox...). I needed to learn tkinter syntax in order to create this micro-software. At first, I wanted to add a "check my password" function but I realized that it'll be useless if the generated passwords were generated strong enough.

I also used the pyperclip module just for one function (copy into the clipboard) and the random module to randomly choose the characters. 

To use my software, you just need to select (or type directly) the wanted length then click "Generate". 
If there's nothing to copy, the program will tell you that you need to generate something first, otherwise the Copy button will copy your password into the clipboard. 